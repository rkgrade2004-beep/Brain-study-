package com.brainstudy.app

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private var score = 0
    private var answer = 0
    private lateinit var question: TextView
    private lateinit var scoreView: TextView
    private lateinit var buttons: List<Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)

        val match = LinearLayout.LayoutParams.MATCH_PARENT
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 16)
        }

        scoreView = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        question = TextView(this).apply {
            textSize = 40f
            gravity = Gravity.CENTER
            setPadding(0, 64, 0, 64)
        }
        root.addView(scoreView)
        root.addView(question)

        buttons = List(4) { Button(this).apply { textSize = 24f } }
        buttons.forEach { b ->
            root.addView(b, LinearLayout.LayoutParams(match, wrap).apply { topMargin = 24 })
        }

        root.addView(Space(this), LinearLayout.LayoutParams(match, 0, 1f))

        val adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BuildConfig.BANNER_ID
        }
        root.addView(adView, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        setContentView(root)
        adView.loadAd(AdRequest.Builder().build())
        nextQuestion()
    }

    private fun nextQuestion() {
        val a = Random.nextInt(2, 13)
        val b = Random.nextInt(2, 13)
        answer = a * b
        question.text = "$a × $b = ?"
        scoreView.text = "Score: $score"

        val options = mutableSetOf(answer)
        while (options.size < 4) {
            val wrong = answer + Random.nextInt(-10, 11)
            if (wrong > 0) options.add(wrong)
        }
        options.shuffled().forEachIndexed { i, value ->
            buttons[i].text = value.toString()
            buttons[i].setOnClickListener {
                score = if (value == answer) score + 1 else maxOf(0, score - 1)
                nextQuestion()
            }
        }
    }
}
